import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;



// 3. Бонус направете още полета, които да съответстват на променливите на потребителя и още един бутон
// При натискане ще добавя нов потребител в масива.
// Добавете и още един бутон, който при натискане ще принтира в конзолата всички потребители.

public class ScreenThree extends JFrame implements ActionListener {

    public JTextField firstNameField;
    public JTextField lastNameField;
    public JTextField PINField;
    public JLabel label;
    public JButton button;
    public JButton ShowInfoButton;
    public JButton addUserButton;
    public ArrayList<User> users;

    public ScreenThree(){
        super("Screen Three - bonus");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        initializerElements();
        addArray();
    }
    public void addArray(){
        users = new ArrayList<User>();

        User u1 = new User("Sunny", "Dineva", 8312099111L);
        User u2 = new User("Emanuela", "Dineva", 1450099333L);
        User u3 = new User("Daria", "Zheleva", 14500992222L);

        users.add(u1);
        users.add(u2);
        users.add(u3);
    }

    public void initializerElements() {
        firstNameField = new JTextField("First name");
        add(firstNameField);

        lastNameField = new JTextField("Last name");
        lastNameField.setSize(200, 4);
        add(lastNameField);


        PINField = new JTextField("PIN");
        add(PINField);

        label = new JLabel("User's info");
        add(label);

        ShowInfoButton = new JButton("Show info");
        ShowInfoButton.addActionListener(this);
        add(ShowInfoButton);

        addUserButton = new JButton("add User");
        addUserButton.addActionListener(this);
        add(addUserButton);
    }

    public void ShowInfoButtonAction(){
        boolean isFound = false;
        for(User user : users){
            if (PINField.getText().isEmpty() || PINField.getText().equals("PIN")) {
                System.out.println("PIN is required");
                return;
            }
            if((Long.parseLong(PINField.getText())) == user.getPIN()){
                label.setText(user.printUser());
                System.out.println(user.printUser());
                isFound = true;
            }
            if(!isFound) {
                label.setText("Result for this PIN not found");
            }
        }
    }
    public void resetFields(){
        firstNameField.setText("First name");
        lastNameField.setText("Last name");
        PINField.setText("PIN");
        label.setText("User's info");
    }
    public void AddUserButtonAction(){
        User user = new User(firstNameField.getText(), lastNameField.getText(), Long.parseLong(PINField.getText()));
        users.add(user);
        resetFields();
        System.out.println("User successfully added");
    }




    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == ShowInfoButton) {
            ShowInfoButtonAction();
        } else if(e.getSource() == addUserButton) {
            AddUserButtonAction();
        }
    }
}
