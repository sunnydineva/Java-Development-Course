

public class Main {
    public static void main(String[] args) {

        ScreenOne screenOne = new ScreenOne();
        screenOne.setVisible(true);

        ScreenTwo screenTwo = new ScreenTwo();
        screenTwo.setVisible(true);

        ScreenThree screenThree = new ScreenThree();
        screenThree.setVisible(true);


    }


}



















