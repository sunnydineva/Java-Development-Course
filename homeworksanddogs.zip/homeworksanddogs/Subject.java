package homeworksanddogs;

public enum Subject {

    MATH, MUSIC, CHEMISTRY;
}
