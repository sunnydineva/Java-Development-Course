package homeworksanddogs;

public interface MainAction {
    void introduce(Person person);
}
