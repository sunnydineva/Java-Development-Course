package homeworksanddogs;

public interface StudentAction {
    boolean isWritten();
}
