package homeworksanddogs;

public interface TeacherActions {

    void askForHoHW(Subject subject, Student student, boolean isWritten);

}
